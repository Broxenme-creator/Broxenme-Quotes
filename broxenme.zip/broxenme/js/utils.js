// Toast notifications
function toast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const div = document.createElement('div');
    div.style.cssText = `padding:0.8rem 1.2rem;border-radius:10px;color:white;font-weight:600;backdrop-filter:blur(20px);font-size:0.85rem;margin-bottom:0.5rem;background:${type==='success'?'rgba(46,213,115,0.9)':type==='error'?'rgba(255,71,87,0.9)':'rgba(0,122,122,0.9)'}`;
    div.innerHTML = `<i class="fa-solid fa-${type==='success'?'circle-check':type==='error'?'circle-xmark':'circle-info'}"></i> ${message}`;
    container.appendChild(div);
    setTimeout(() => { div.style.opacity = '0'; div.style.transition = '0.3s'; setTimeout(() => div.remove(), 300); }, 3000);
}

// Sanitize text
function san(s) {
    const div = document.createElement('div');
    div.textContent = s || '';
    return div.innerHTML;
}

// Clean up listeners
function cleanUp() {
    unsubscribers.forEach(u => { try { u(); } catch(e) {} });
    unsubscribers = [];
}

// Random wallpaper
function getRandomWallpaper() {
    const walls = [
        'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800',
        'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800',
        'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800'
    ];
    return walls[Math.floor(Math.random() * walls.length)];
}

// Upload image to ImgBB
async function uploadImage(file) {
    const fd = new FormData();
    fd.append('image', file);
    const r = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_KEY}`, { method: 'POST', body: fd });
    const d = await r.json();
    return d.success ? d.data.url : '';
}

// Constants
const gradients = [
    'linear-gradient(135deg, #667eea, #764ba2)',
    'linear-gradient(135deg, #f093fb, #f5576c)',
    'linear-gradient(135deg, #43e97b, #38f9d7)',
    'linear-gradient(135deg, #fa709a, #fee140)',
    'linear-gradient(135deg, #30cfd0, #330867)',
    'linear-gradient(135deg, #a8edea, #fed6e3)',
    'linear-gradient(135deg, #ff9a9e, #fecfef)',
    'linear-gradient(135deg, #ffecd2, #fcb69f)'
];
const fonts = ['Poppins', 'Georgia', 'Arial', 'Impact', 'Courier New', 'Trebuchet MS', 'Verdana', 'Times New Roman', 'Comic Sans MS', 'Roboto'];
const textColors = ['#ffffff', '#000000', '#ADFF2F', '#FFD700', '#ff4757', '#2ed573', '#ffa502', '#1DA1F2', '#8B5CF6', '#EC4899', '#00d4ff', '#ff6b6b', '#4ecdc4', '#f9ca24'];
const bgColors = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#43e97b', '#38f9d7', '#fa709a', '#330867', '#30cfd0', '#a8edea', '#ff9a9e', '#ffecd2', '#1a1a2e', '#0f0f23'];
const borderStyles = ['none', '2px solid white', '4px double white', '2px dashed white', '0 0 15px rgba(255,255,255,0.4)', 'text-shadow:0 0 8px #ADFF2F', 'text-shadow:0 0 8px #ff4757', '-webkit-text-stroke:1px white'];
const borderIcons = ['fa-ban', 'fa-border-all', 'fa-grip-lines', 'fa-ellipsis', 'fa-sun', 'fa-bolt', 'fa-heart', 'fa-font'];
const quoteTags = ['Motivation', 'Life', 'Love', 'Success', 'Business', 'Wisdom', 'Spiritual', 'Humor'];
const reactionEmojis = ['❤️', '🔥', '😂', '😭', '🙏', '💯', '👏', '🚀'];