// Auth state observer
auth.onAuthStateChanged(user => {
    if (user) {
        currentUser = user;
        updateNavForAuth();
        loadUserProfile();
        loadNotifications();
        updateStreak();
        setupBots();
        navigateTo('reels');
    } else {
        cleanUp();
        currentUser = null;
        updateNavForGuest();
        navigateTo('home');
    }
});

function updateNavForAuth() {
    document.getElementById('authBtn').innerText = 'Logout';
    document.getElementById('authBtn').onclick = logout;
    document.getElementById('navProfileIcon').style.display = 'block';
    document.getElementById('navNotifIcon').style.display = 'block';
    db.collection('users').doc(currentUser.uid).get().then(doc => {
        if (doc.exists) {
            document.getElementById('navProfilePic').src = doc.data().photoURL || 'https://placehold.co/40';
        }
    });
}

function updateNavForGuest() {
    document.getElementById('authBtn').innerText = 'Login';
    document.getElementById('authBtn').onclick = () => navigateTo('login');
    document.getElementById('navProfileIcon').style.display = 'none';
    document.getElementById('navNotifIcon').style.display = 'none';
}

function login() {
    const email = document.getElementById('loginEmail').value.trim();
    const pass = document.getElementById('loginPass').value;
    if (!email || !pass) return toast('Fill all fields', 'error');
    auth.signInWithEmailAndPassword(email, pass)
        .then(() => toast('Welcome!', 'success'))
        .catch(err => toast(err.message, 'error'));
}

function signup() {
    const email = document.getElementById('loginEmail').value.trim();
    const pass = document.getElementById('loginPass').value;
    if (!email || !pass) return toast('Fill all fields', 'error');
    if (pass.length < 6) return toast('Password too short', 'error');
    auth.createUserWithEmailAndPassword(email, pass)
        .then(cred => {
            db.collection('users').doc(cred.user.uid).set({
                name: email.split('@')[0],
                bio: '',
                location: 'Harare, ZW',
                photoURL: '',
                followers: 0,
                following: 0,
                savedPosts: [],
                website: '',
                streak: 0,
                lastVisit: firebase.firestore.FieldValue.serverTimestamp(),
                isVerified: false,
                tags: [],
                collections: { Motivation: [], Love: [], Business: [], Life: [] },
                achievements: []
            });
            toast('Account created!', 'success');
        })
        .catch(err => toast(err.message, 'error'));
}

function logout() {
    cleanUp();
    if (audio) { audio.pause(); audio.remove(); audio = null; }
    auth.signOut();
}

// Streak tracking
async function updateStreak() {
    if (!currentUser) return;
    const ref = db.collection('users').doc(currentUser.uid);
    const doc = await ref.get();
    if (!doc.exists) return;
    const data = doc.data();
    const now = new Date();
    const lastVisit = data.lastVisit ? data.lastVisit.toDate() : null;
    let streak = data.streak || 0;
    if (lastVisit) {
        const diffDays = Math.floor((now - lastVisit) / (1000 * 60 * 60 * 24));
        if (diffDays === 1) streak++;
        else if (diffDays > 1) streak = 1;
    } else {
        streak = 1;
    }
    let achievements = data.achievements || [];
    if (streak >= 7 && !achievements.includes('7day')) {
        achievements.push('7day');
        toast('🏆 Unlocked: 7 Day Streak!', 'success');
    }
    if (streak >= 30 && !achievements.includes('30day')) {
        achievements.push('30day');
        toast('🏆 Unlocked: 30 Day Streak!', 'success');
    }
    await ref.update({ streak, lastVisit: firebase.firestore.FieldValue.serverTimestamp(), achievements });
}

// Bots
const bots = [
    { e: 'wisdom@broxenme.com', p: 'bot123456', n: 'Wisdom Warrior', l: 'Nairobi, KE', pic: 'https://placehold.co/100/ADFF2F/000?text=WW' },
    { e: 'dreamer@broxenme.com', p: 'bot123456', n: 'Dream Chaser', l: 'Lagos, NG', pic: 'https://placehold.co/100/FF6B6B/000?text=DC' },
    { e: 'soul@broxenme.com', p: 'bot123456', n: 'Soul Speaker', l: 'Cape Town, ZA', pic: 'https://placehold.co/100/4ECDC4/000?text=SS' }
];

async function setupBots() {
    for (const bot of bots) {
        try {
            const cred = await auth.createUserWithEmailAndPassword(bot.e, bot.p);
            await db.collection('users').doc(cred.user.uid).set({
                name: bot.n, location: bot.l, photoURL: bot.pic,
                bio: 'Spreading positivity ✨', followers: Math.floor(Math.random() * 300),
                following: 0, savedPosts: [], isDummy: true, isVerified: true,
                streak: Math.floor(Math.random() * 30), collections: {}, website: '', achievements: []
            });
            await auth.signOut();
        } catch (e) {}
    }
    if (!currentUser) {
        try { await auth.signInAnonymously(); } catch (e) {}
    }
}

// Auto-post for bots
async function autoPost() {
    const users = await db.collection('users').where('isDummy', '==', true).get();
    const quotes = ['The journey of a thousand miles begins with one step.', 'Your vibe attracts your tribe.', 'Dream big, work hard, stay focused.', 'Every moment is a fresh beginning.'];
    for (const doc of users.docs) {
        await db.collection('posts').add({
            text: quotes[Math.floor(Math.random() * quotes.length)],
            bg: gradients[Math.floor(Math.random() * gradients.length)],
            font: fonts[Math.floor(Math.random() * fonts.length)],
            tags: ['Motivation'],
            authorId: doc.id,
            authorName: doc.data().name,
            authorPic: doc.data().photoURL,
            time: firebase.firestore.FieldValue.serverTimestamp(),
            likes: Math.floor(Math.random() * 40),
            views: Math.floor(Math.random() * 150),
            shares: Math.floor(Math.random() * 10),
            commentsCount: Math.floor(Math.random() * 5)
        });
    }
}
setInterval(autoPost, 43200000);
setTimeout(autoPost, 15000);