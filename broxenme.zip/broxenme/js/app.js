// Load components when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadNavbar();
    loadModals();
    navigateTo('home');
    initTheme();
});

function loadNavbar() {
    document.getElementById('navbarContainer').innerHTML = `
    <nav>
        <div class="nav-logo" onclick="navigateTo('home')"><div class="icon"><i class="fa-solid fa-quote-left"></i></div>BROXENME</div>
        <ul id="navMenu">
            <li><a onclick="event.preventDefault();navigateTo('home')"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a onclick="event.preventDefault();navigateTo('reels')"><i class="fa-solid fa-play"></i> Reels</a></li>
            <li><a onclick="event.preventDefault();navigateTo('community')"><i class="fa-solid fa-users"></i> Community</a></li>
            <li><a onclick="event.preventDefault();navigateTo('discover')"><i class="fa-solid fa-compass"></i> Discover</a></li>
            <li><a onclick="event.preventDefault();navigateTo('profile')"><i class="fa-solid fa-user"></i> Profile</a></li>
            <li><a onclick="event.preventDefault();event.stopPropagation();openManual()"><i class="fa-solid fa-book"></i> Manual</a></li>
        </ul>
        <div class="nav-right">
            <div class="nav-profile" id="navNotifIcon" onclick="toggleNotifications()" style="display:none;cursor:pointer">
                <i class="fa-solid fa-bell" style="font-size:1.3rem;color:var(--text)"></i>
                <span class="badge" id="notifBadge" style="position:absolute;top:-5px;right:-5px;background:var(--danger);color:white;border-radius:50%;width:20px;height:20px;font-size:0.7rem;display:flex;align-items:center;justify-content:center;font-weight:bold"></span>
            </div>
            <div class="nav-profile" id="navProfileIcon" onclick="currentUser?navigateTo('profile'):navigateTo('login')" style="display:none">
                <img src="https://placehold.co/40" id="navProfilePic" alt="Profile">
                <span class="badge" id="navNotificationBadge"></span>
            </div>
            <button class="nav-btn" id="authBtn" onclick="currentUser?logout():navigateTo('login')">Login</button>
            <button id="themeToggle"><i class="fa-solid fa-gear"></i></button>
            <div class="hamburger" onclick="toggleMenu()"><i class="fa-solid fa-bars"></i></div>
        </div>
    </nav>`;
}

function loadModals() {
    document.getElementById('modalsContainer').innerHTML = `
    <!-- Edit Profile Modal -->
    <div id="editProfileModal" class="modal">
        <div class="modal-content glass">
            <div class="modal-header"><i class="fa-solid fa-user-pen"></i> Edit Profile</div>
            <div class="form-group"><label>Name</label><input type="text" id="editName"></div>
            <div class="form-group"><label>Location</label><input type="text" id="editLocation"></div>
            <div class="form-group"><label>Bio</label><textarea id="editBio" rows="3"></textarea></div>
            <button class="btn" onclick="saveProfile()"><i class="fa-solid fa-floppy-disk"></i> Save</button>
            <button class="btn-outline" style="margin-top:0.8rem" onclick="closeEditProfile()"><i class="fa-solid fa-xmark"></i> Cancel</button>
        </div>
    </div>
    
    <!-- Feed Comments Modal -->
    <div id="feedCommentsModal" class="modal">
        <div class="modal-content glass" style="max-width:600px">
            <div class="modal-header"><i class="fa-solid fa-comments"></i> Comments</div>
            <div id="feedCommentsList" style="max-height:50vh;overflow-y:auto;margin-bottom:1rem"></div>
            <div style="display:flex;gap:0.5rem">
                <input type="text" id="feedCommentInput" placeholder="Add a comment..." style="flex:1;padding:0.8rem;border-radius:20px;background:rgba(255,255,255,0.1);color:var(--text);border:1px solid var(--glass-border)">
                <button class="btn" onclick="submitFeedComment()" style="width:auto"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
            <button class="btn-outline" style="margin-top:0.8rem" onclick="closeFeedComments()"><i class="fa-solid fa-xmark"></i> Close</button>
        </div>
    </div>
    
    <!-- Group Chat Window -->
    <div id="groupChatWindow" class="group-chat-window">
        <div class="chat-header">
            <button onclick="closeGroupChat()" style="background:none;border:none;color:white;font-size:1.2rem"><i class="fa-solid fa-arrow-left"></i></button>
            <img src="https://placehold.co/45" id="groupChatAvatar">
            <div class="header-info"><h4 id="groupChatName">Group</h4><p id="groupChatMemberCount">0 members</p></div>
        </div>
        <div class="chat-messages" id="groupChatMessages"></div>
        <div class="chat-input-area">
            <input type="text" id="groupChatInput" placeholder="Message..." onkeypress="if(event.key==='Enter')sendGroupMsg()">
            <button onclick="sendGroupMsg()"><i class="fa-solid fa-paper-plane"></i></button>
        </div>
    </div>
    
    <!-- Advanced Creator -->
    <div id="advancedCreator" class="advanced-creator">
        <div class="creator-header glass">
            <button onclick="closeCreator()" style="background:none;border:none;color:white;font-size:1.3rem"><i class="fa-solid fa-xmark"></i></button>
            <span style="font-weight:700">Create Post</span>
            <button class="btn btn-small" onclick="submitAdvancedPost()"><i class="fa-solid fa-check"></i> Post</button>
        </div>
        <div class="creator-body">
            <div class="creator-canvas">
                <div class="canvas-container" id="canvasWrapper">
                    <img id="creatorImage" src="" style="display:none">
                    <div class="draggable-text" id="creatorText">Your Quote</div>
                </div>
            </div>
            <div class="creator-tools glass">
                <h4><i class="fa-solid fa-pen"></i> Quote Text</h4>
                <textarea id="creatorQuoteInput" placeholder="Write your quote..." oninput="document.getElementById('creatorText').innerText=this.value||'Your Quote'" style="width:100%;padding:0.5rem;border-radius:8px;background:rgba(255,255,255,0.08);color:white;border:1px solid rgba(255,255,255,0.15);outline:none;resize:vertical;min-height:60px;font-size:0.8rem"></textarea>
                <h4><i class="fa-solid fa-palette"></i> Text Color</h4>
                <div class="color-grid" id="textColorGrid">${textColors.map(c=>`<div class="color-dot" style="background:${c}" onclick="setCreatorTextColor('${c}')"></div>`).join('')}</div>
                <h4><i class="fa-solid fa-font"></i> Font</h4>
                <div class="font-scroll" id="creatorFontScroll">${fonts.map(f=>`<div class="font-opt" onclick="setCreatorFont('${f}')" style="font-family:'${f}'">${f.split(' ')[0]}</div>`).join('')}</div>
                <h4><i class="fa-solid fa-image"></i> Background</h4>
                <input type="file" id="creatorBgUpload" accept="image/*" onchange="uploadCreatorBg(event)" style="color:white;font-size:0.8rem;margin:0.3rem 0">
                <div class="color-grid" id="bgColorGrid" style="margin-top:0.5rem">${bgColors.map(c=>`<div class="color-dot" style="background:${c}" onclick="setCreatorBgColor('${c}')"></div>`).join('')}</div>
                <h4><i class="fa-solid fa-crop"></i> Crop</h4>
                <div class="crop-btns" style="display:flex;gap:0.3rem;flex-wrap:wrap">
                    <button onclick="cropImage('1:1')" style="padding:0.3rem 0.6rem;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:transparent;color:white;cursor:pointer;font-size:0.7rem">1:1</button>
                    <button onclick="cropImage('4:5')" style="padding:0.3rem 0.6rem;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:transparent;color:white;cursor:pointer;font-size:0.7rem">4:5</button>
                    <button onclick="cropImage('9:16')" style="padding:0.3rem 0.6rem;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:transparent;color:white;cursor:pointer;font-size:0.7rem">9:16</button>
                    <button onclick="cropImage('16:9')" style="padding:0.3rem 0.6rem;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:transparent;color:white;cursor:pointer;font-size:0.7rem">16:9</button>
                    <button onclick="resetCrop()" style="padding:0.3rem 0.6rem;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:transparent;color:white;cursor:pointer;font-size:0.7rem"><i class="fa-solid fa-rotate-left"></i></button>
                </div>
                <h4><i class="fa-solid fa-text-height"></i> Text Size</h4>
                <input type="range" id="textSizeSlider" min="12" max="72" value="24" oninput="updateTextSize()" style="width:100%;accent-color:var(--accent)">
                <h4><i class="fa-solid fa-layer-group"></i> Post Type</h4>
                <select id="creatorPostType" style="width:100%;padding:0.5rem;border-radius:8px;background:rgba(255,255,255,0.08);color:white;border:1px solid rgba(255,255,255,0.15);outline:none;font-size:0.8rem">
                    <option value="reel">Reel</option>
                    <option value="feed">Feed Post</option>
                </select>
            </div>
        </div>
    </div>`;
    
    // Initialize draggable after modals are loaded
    setTimeout(() => {
        const draggable = document.getElementById('creatorText');
        if (draggable) makeDraggable(draggable);
    }, 100);
}

// Navigation - FIXED
function navigateTo(page) {
    // Close mobile menu
    document.getElementById('navMenu')?.classList.remove('active');
    
    // Close any open modals
    document.querySelectorAll('.modal.active').forEach(m => m.classList.remove('active'));
    document.querySelectorAll('.group-chat-window.active').forEach(w => w.classList.remove('active'));
    
    const container = document.getElementById('pageContainer');
    
    switch(page) {
        case 'home': loadHomePage(); break;
        case 'reels': loadReelsPage(); break;
        case 'community': loadCommunityPage(); break;
        case 'discover': loadDiscoverPage(); break;
        case 'profile': loadProfilePage(); break;
        case 'login': loadLoginPage(); break;
    }
}

function loadHomePage() {
    document.getElementById('pageContainer').innerHTML = `
        <section class="hero"><h2 style="color:white;margin-bottom:0.5rem">Daily Inspiration</h2><p id="dailyQuote">"Loading..."</p><button class="btn" onclick="newDailyQuote()" style="width:auto;margin-top:1.5rem"><i class="fa-solid fa-shuffle"></i> New Quote</button></section>
        <div style="max-width:700px;margin:0 auto;padding:1rem"><h3 style="margin-bottom:1rem"><i class="fa-solid fa-fire"></i> Trending Quotes</h3><div id="trendingQuotes" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px"></div></div>
    `;
    newDailyQuote();
    loadTrending();
}

function loadLoginPage() {
    document.getElementById('pageContainer').innerHTML = `
        <div class="card glass" style="margin-top:2rem">
            <h2 style="font-size:1.3rem"><i class="fa-solid fa-right-to-bracket"></i> Welcome to Broxenme</h2>
            <div class="form-group"><label>Email</label><input type="email" id="loginEmail" placeholder="you@email.com"></div>
            <div class="form-group"><label>Password</label><input type="password" id="loginPass" placeholder="********"></div>
            <button class="btn" onclick="login()"><i class="fa-solid fa-key"></i> Login</button>
            <button class="btn-outline" style="margin-top:0.8rem" onclick="signup()"><i class="fa-solid fa-user-plus"></i> Sign Up</button>
        </div>
    `;
}

async function newDailyQuote() {
    const fallback = [
        {q:"The only way to do great work is to love what you do.",a:"Steve Jobs"},
        {q:"In the middle of difficulty lies opportunity.",a:"Albert Einstein"},
        {q:"Believe you can and you're halfway there.",a:"Theodore Roosevelt"},
        {q:"Your vibe attracts your tribe.",a:"Unknown"}
    ];
    try {
        const r = await fetch('https://api.quotable.io/random?maxLength=120');
        if (r.ok) { const d = await r.json(); document.getElementById('dailyQuote').innerText = `"${d.content}" — ${d.author}`; return; }
    } catch(e) {}
    const q = fallback[Math.floor(Math.random() * fallback.length)];
    document.getElementById('dailyQuote').innerText = `"${q.q}" — ${q.a}`;
}

async function loadTrending() {
    const snap = await db.collection('posts').orderBy('likes', 'desc').limit(6).get();
    const container = document.getElementById('trendingQuotes');
    if (!container) return;
    container.innerHTML = '';
    snap.forEach(doc => {
        const p = doc.data();
        container.innerHTML += `<div style="background:${p.bg||gradients[0]};font-family:${p.font||'Poppins'};aspect-ratio:1;border-radius:12px;display:flex;align-items:center;justify-content:center;padding:1rem;text-align:center;font-weight:bold;color:white;cursor:pointer;font-size:0.75rem" onclick="navigateTo('reels')">${san(p.text.substring(0,30))}</div>`;
    });
}

function toggleMenu() { document.getElementById('navMenu').classList.toggle('active'); }

function initTheme() {
    document.getElementById('themeToggle').onclick = () => {
        document.body.classList.toggle('light');
        localStorage.setItem('theme', document.body.classList.contains('light') ? 'light' : 'dark');
    };
    if (localStorage.getItem('theme') === 'light') document.body.classList.add('light');
}

// Manual - FIXED to not interfere with other pages
function openManual() {
    // Remove any existing manual page
    const existing = document.getElementById('manualOverlay');
    if (existing) existing.remove();
    
    // Create new manual overlay
    const overlay = document.createElement('div');
    overlay.id = 'manualOverlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.93);z-index:5000;overflow-y:auto;';
    overlay.onclick = function(e) {
        if (e.target === overlay) overlay.remove();
    };
    
    overlay.innerHTML = `
        <div style="max-width:850px;margin:2rem auto;padding:2rem;color:white">
            <button onclick="this.closest('#manualOverlay').remove()" style="position:fixed;top:20px;right:20px;background:var(--danger);border:none;color:white;width:45px;height:45px;border-radius:50%;cursor:pointer;font-size:1.2rem;z-index:10"><i class="fa-solid fa-xmark"></i></button>
            <h1 style="font-size:2rem;text-align:center;background:linear-gradient(135deg,var(--accent),var(--purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:1rem"><i class="fa-solid fa-book-open"></i> BROXENME Manual</h1>
            <p style="text-align:center;color:var(--muted);margin-bottom:2rem">Complete guide to the Quote Social Platform</p>
            
            <div style="background:rgba(255,255,255,0.04);border-radius:14px;padding:1.2rem;margin:0.8rem 0;border:1px solid rgba(255,255,255,0.08);overflow-x:auto">
                <pre style="font-size:0.65rem;line-height:1.3;color:var(--accent)">
┌──────────────────────────────────────────────────┐
│  🔥 BROXENME - Quote Social Platform              │
│  ┌──────┐ ┌───────┐ ┌──────────┐ ┌─────────┐    │
│  │ Home │ │ Reels │ │ Community│ │ Discover│    │
│  └──────┘ └───────┘ └──────────┘ └─────────┘    │
│  • Daily Quotes    • TikTok-style reels          │
│  • Trending        • Double-tap like             │
│  • Games           • Comments & replies          │
└──────────────────────────────────────────────────┘</pre>
            </div>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-house"></i> Home Page</h2>
            <p>Daily inspirational quotes from quotable.io with local fallbacks. Trending quotes sorted by likes.</p>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-play"></i> Reels Page</h2>
            <ul style="margin:0.5rem 0 0.5rem 1.5rem;color:var(--muted);font-size:0.9rem">
                <li>Full-screen vertical scrolling (TikTok/Instagram style)</li>
                <li>Like, comment, share, and save with sidebar buttons</li>
                <li>Transparent search bar at top</li>
                <li>Comments slide up - reply, like/dislike comments</li>
                <li>Creator badge on post author's comments</li>
                <li>Emoji reactions (❤️🔥😂😭🙏💯👏🚀)</li>
            </ul>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-users"></i> Community Page</h2>
            <ul style="margin:0.5rem 0 0.5rem 1.5rem;color:var(--muted);font-size:0.9rem">
                <li>Feed tab: Create posts with image upload, like, comment</li>
                <li>Polls: Create and vote on community polls</li>
                <li>Groups tab: WhatsApp-style chat, search/join groups</li>
                <li>Unread message badges (excludes your own messages)</li>
                <li>Group details with member list and follow buttons</li>
            </ul>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-compass"></i> Discover Page</h2>
            <p>Find other users by searching name, bio, location, or tags. Filter by category.</p>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-user"></i> Profile Page</h2>
            <ul style="margin:0.5rem 0 0.5rem 1.5rem;color:var(--muted);font-size:0.9rem">
                <li>Stats: Posts, Followers, Following, Likes (all live-updating)</li>
                <li>Tabs: Posts, Saved, Feeds, Groups</li>
                <li>My Tags dropdown for discoverability</li>
                <li>Advanced Post Creator with draggable text, fonts, colors, crop</li>
                <li>Streak counter tracks daily visits</li>
                <li>Edit profile, share profile, DM button</li>
            </ul>
            
            <h2 style="color:var(--accent);margin:1.5rem 0 0.6rem;font-size:1.3rem;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:0.4rem"><i class="fa-solid fa-wand-magic-sparkles"></i> Advanced Creator</h2>
            <ul style="margin:0.5rem 0 0.5rem 1.5rem;color:var(--muted);font-size:0.9rem">
                <li>Draggable text - position your quote anywhere</li>
                <li>14+ fonts, 14+ text colors, 14+ backgrounds</li>
                <li>Crop tools: 1:1, 4:5, 9:16, 16:9</li>
                <li>Text size slider (12px-72px)</li>
                <li>Image upload for backgrounds</li>
            </ul>
            
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin:1.5rem 0">
                <div style="background:rgba(255,255,255,0.04);padding:1.2rem;border-radius:14px;text-align:center;border:1px solid rgba(255,255,255,0.08)">
                    <i class="fa-solid fa-heart" style="font-size:2rem;color:var(--accent);margin-bottom:0.5rem"></i>
                    <h4 style="font-size:0.9rem">Likes System</h4>
                    <p style="font-size:0.75rem;color:var(--muted)">Real-time across all pages</p>
                </div>
                <div style="background:rgba(255,255,255,0.04);padding:1.2rem;border-radius:14px;text-align:center;border:1px solid rgba(255,255,255,0.08)">
                    <i class="fa-solid fa-comment" style="font-size:2rem;color:var(--accent);margin-bottom:0.5rem"></i>
                    <h4 style="font-size:0.9rem">Comments</h4>
                    <p style="font-size:0.75rem;color:var(--muted)">Reply & like/dislike</p>
                </div>
                <div style="background:rgba(255,255,255,0.04);padding:1.2rem;border-radius:14px;text-align:center;border:1px solid rgba(255,255,255,0.08)">
                    <i class="fa-solid fa-users-between-lines" style="font-size:2rem;color:var(--accent);margin-bottom:0.5rem"></i>
                    <h4 style="font-size:0.9rem">Groups</h4>
                    <p style="font-size:0.75rem;color:var(--muted)">WhatsApp-style chat</p>
                </div>
                <div style="background:rgba(255,255,255,0.04);padding:1.2rem;border-radius:14px;text-align:center;border:1px solid rgba(255,255,255,0.08)">
                    <i class="fa-solid fa-fire" style="font-size:2rem;color:var(--accent);margin-bottom:0.5rem"></i>
                    <h4 style="font-size:0.9rem">Streaks</h4>
                    <p style="font-size:0.75rem;color:var(--muted)">Daily visit tracking</p>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(overlay);
}

// Notifications placeholder
function toggleNotifications() {
    toast('Notifications panel ready for expansion', 'info');
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    cleanUp();
    if (audio) { audio.pause(); audio.remove(); }
});

console.log('🚀 BROXENME App Controller Loaded!');