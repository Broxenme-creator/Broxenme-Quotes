function loadReelsPage() {
    const container = document.getElementById('pageContainer');
    container.innerHTML = `
        <div class="reels-container">
            <div class="reel-search-overlay">
                <input type="text" id="reelSearchInput" placeholder="🔍 Search quotes, tags, users..." oninput="searchReels()">
            </div>
            <div class="reels-viewer" id="reelsViewer"></div>
        </div>
    `;
    if (currentUser) loadReels();
}

function loadReels() {
    if (!currentUser) return;
    cleanUp();
    const unsub = db.collection('posts').orderBy('time', 'desc').limit(50).onSnapshot(snapshot => {
        allPosts = [];
        const viewer = document.getElementById('reelsViewer');
        if (!viewer) return;
        let html = '';
        snapshot.forEach(doc => {
            const post = doc.data();
            post.id = doc.id;
            allPosts.push(post);
            html += buildReelHTML(post);
        });
        viewer.innerHTML = html;
        snapshot.forEach(doc => {
            loadComments(doc.id, doc.data().authorId);
        });
    });
    unsubscribers.push(unsub);
}

function buildReelHTML(post) {
    return `
    <div class="reel-full" style="background:${post.bg || gradients[0]}" id="reel_${post.id}">
        <div class="reel-overlay"></div>
        <div class="reel-content">
            <div class="reel-text" style="font-family:${post.font || 'Poppins'}">${san(post.text)}</div>
            <div class="reel-tags">${(post.tags || []).map(t => `<span class="reel-tag">#${san(t)}</span>`).join('')}</div>
            <div class="reel-user-row">
                <img src="${post.authorPic || 'https://placehold.co/40'}" onclick="viewProfile('${post.authorId}')">
                <span class="username" onclick="viewProfile('${post.authorId}')">@${san(post.authorName)}</span>
            </div>
        </div>
        <div class="reel-actions">
            <div class="reel-action-btn" onclick="toggleLike('${post.id}', this)">
                <i class="fa-regular fa-heart"></i><span>${post.likes || 0}</span>
            </div>
            <div class="reel-action-btn" onclick="toggleComments('${post.id}')">
                <i class="fa-solid fa-comment"></i><span>${post.commentsCount || 0}</span>
            </div>
            <div class="reel-action-btn" onclick="sharePost('${post.id}')">
                <i class="fa-solid fa-share-nodes"></i><span>Share</span>
            </div>
            <div class="reel-action-btn" onclick="savePost('${post.id}')">
                <i class="fa-regular fa-bookmark"></i>
            </div>
        </div>
        <div style="position:absolute;bottom:60px;left:1rem;z-index:3">
            ${reactionEmojis.map(e => `<button class="reaction-emoji" onclick="addReaction('${post.id}','${e}')">${e}</button>`).join('')}
        </div>
        <div class="comments-panel" id="comments_${post.id}">
            <div class="comments-panel-header">
                <span><i class="fa-solid fa-comments"></i> Comments</span>
                <button onclick="toggleComments('${post.id}')" style="background:none;border:none;color:white;cursor:pointer"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="comments-list" id="commentList_${post.id}"></div>
            <div class="comment-input-bar">
                <input type="text" id="commentInput_${post.id}" placeholder="Add comment...">
                <button class="btn btn-small" onclick="addComment('${post.id}')" style="width:auto"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>`;
}

async function toggleLike(postId, btn) {
    if (!currentUser) return toast('Login first', 'error');
    const ref = db.collection('likes').doc(currentUser.uid + '_' + postId);
    const doc = await ref.get();
    if (doc.exists) {
        await ref.delete();
        await db.collection('posts').doc(postId).update({ likes: firebase.firestore.FieldValue.increment(-1) });
        btn.classList.remove('liked');
    } else {
        await ref.set({ userId: currentUser.uid });
        await db.collection('posts').doc(postId).update({ likes: firebase.firestore.FieldValue.increment(1) });
        btn.classList.add('liked');
    }
}

function toggleComments(postId) {
    const panel = document.getElementById('comments_' + postId);
    if (panel) panel.classList.toggle('active');
}

async function addComment(postId) {
    const input = document.getElementById('commentInput_' + postId);
    if (!input || !currentUser) return;
    const text = input.value.trim();
    if (!text) return;
    const replyTo = input.dataset.replyTo || null;
    await db.collection('posts').doc(postId).collection('comments').add({
        text, replyTo,
        authorId: currentUser.uid,
        authorName: currentUser.email.split('@')[0],
        time: firebase.firestore.FieldValue.serverTimestamp(),
        likes: 0, dislikes: 0
    });
    await db.collection('posts').doc(postId).update({ commentsCount: firebase.firestore.FieldValue.increment(1) });
    input.value = '';
    input.dataset.replyTo = '';
    input.placeholder = 'Add comment...';
}

function loadComments(postId, postAuthorId) {
    db.collection('posts').doc(postId).collection('comments').orderBy('time', 'asc').onSnapshot(snap => {
        const list = document.getElementById('commentList_' + postId);
        if (!list) return;
        if (snap.empty) {
            list.innerHTML = '<p style="color:var(--muted);text-align:center;padding:1rem;font-size:0.8rem">No comments</p>';
            return;
        }
        list.innerHTML = '';
        const topLevel = [], replies = {};
        snap.forEach(doc => {
            const c = doc.data(); c.id = doc.id;
            if (c.replyTo) { if (!replies[c.replyTo]) replies[c.replyTo] = []; replies[c.replyTo].push(c); }
            else topLevel.push(c);
        });
        topLevel.forEach(c => {
            list.innerHTML += renderCommentHTML(c, postId, postAuthorId);
            if (replies[c.id]) replies[c.id].forEach(r => list.innerHTML += renderCommentHTML(r, postId, postAuthorId, true));
        });
    });
}

function renderCommentHTML(c, postId, postAuthorId, isReply = false) {
    return `
    <div class="comment-item ${isReply ? 'reply-item' : ''}">
        <span class="comment-author">${san(c.authorName)}</span>
        ${c.authorId === postAuthorId ? '<span class="creator-badge">Creator</span>' : ''}
        <div class="comment-text">${san(c.text)}</div>
        <div class="comment-actions">
            <span onclick="likeComment('${postId}','${c.id}')"><i class="fa-regular fa-heart"></i> ${c.likes || 0}</span>
            <span onclick="dislikeComment('${postId}','${c.id}')"><i class="fa-regular fa-thumbs-down"></i> ${c.dislikes || 0}</span>
            ${!isReply ? `<span onclick="setReply('${postId}','${c.id}')" style="cursor:pointer;font-size:0.7rem;color:var(--muted)"><i class="fa-solid fa-reply"></i> Reply</span>` : ''}
        </div>
    </div>`;
}

function setReply(postId, commentId) {
    const input = document.getElementById('commentInput_' + postId);
    if (input) { input.dataset.replyTo = commentId; input.placeholder = 'Replying...'; input.focus(); }
}

async function likeComment(postId, commentId) {
    if (!currentUser) return;
    const ref = db.collection('posts').doc(postId).collection('comments').doc(commentId).collection('commentLikes').doc(currentUser.uid);
    const doc = await ref.get();
    if (doc.exists) {
        await ref.delete();
        await db.collection('posts').doc(postId).collection('comments').doc(commentId).update({ likes: firebase.firestore.FieldValue.increment(-1) });
    } else {
        await ref.set({});
        await db.collection('posts').doc(postId).collection('comments').doc(commentId).update({ likes: firebase.firestore.FieldValue.increment(1) });
    }
}

async function dislikeComment(postId, commentId) {
    if (!currentUser) return;
    const ref = db.collection('posts').doc(postId).collection('comments').doc(commentId).collection('commentDislikes').doc(currentUser.uid);
    const doc = await ref.get();
    if (doc.exists) {
        await ref.delete();
        await db.collection('posts').doc(postId).collection('comments').doc(commentId).update({ dislikes: firebase.firestore.FieldValue.increment(-1) });
    } else {
        await ref.set({});
        await db.collection('posts').doc(postId).collection('comments').doc(commentId).update({ dislikes: firebase.firestore.FieldValue.increment(1) });
    }
}

async function savePost(postId) {
    if (!currentUser) return toast('Login first', 'error');
    const ref = db.collection('users').doc(currentUser.uid);
    const doc = await ref.get();
    let saved = doc.data()?.savedPosts || [];
    const wasSaved = saved.includes(postId);
    if (wasSaved) saved = saved.filter(x => x !== postId);
    else saved.push(postId);
    await ref.update({ savedPosts: saved });
    toast(wasSaved ? 'Removed' : 'Saved!', wasSaved ? 'info' : 'success');
}

async function sharePost(postId) {
    const post = allPosts.find(p => p.id === postId);
    if (!post) return;
    const canvas = document.createElement('canvas');
    canvas.width = 1080; canvas.height = 1920;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#1a1a2e'; ctx.fillRect(0, 0, 1080, 1920);
    ctx.fillStyle = 'white'; ctx.font = 'bold 60px Poppins'; ctx.textAlign = 'center';
    ctx.fillText(`"${post.text}"`, 540, 800);
    ctx.fillStyle = '#ADFF2F'; ctx.font = 'bold 30px Poppins';
    ctx.fillText('BROXENME', 540, 1400);
    canvas.toBlob(blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `broxenme-${Date.now()}.png`; a.click();
        toast('Saved to gallery!', 'success');
        db.collection('posts').doc(postId).update({ shares: firebase.firestore.FieldValue.increment(1) });
    });
}

async function addReaction(postId, emoji) {
    if (!currentUser) return;
    const ref = db.collection('posts').doc(postId).collection('reactions').doc(currentUser.uid);
    const doc = await ref.get();
    if (doc.exists && doc.data().emoji === emoji) { await ref.delete(); }
    else { await ref.set({ emoji, time: firebase.firestore.FieldValue.serverTimestamp() }); }
}

function searchReels() {
    clearTimeout(window.searchTimeout);
    window.searchTimeout = setTimeout(() => {
        const q = document.getElementById('reelSearchInput')?.value?.toLowerCase() || '';
        if (!q) { loadReels(); return; }
        const filtered = allPosts.filter(p =>
            (p.text || '').toLowerCase().includes(q) ||
            (p.authorName || '').toLowerCase().includes(q) ||
            (p.tags || []).some(t => t.toLowerCase().includes(q))
        );
        const viewer = document.getElementById('reelsViewer');
        if (viewer) {
            viewer.innerHTML = filtered.length
                ? filtered.map(p => `<div class="reel-full" style="background:${p.bg}"><div class="reel-text">${san(p.text)}</div></div>`).join('')
                : '<p style="text-align:center;padding:2rem;color:var(--muted)">No results</p>';
        }
    }, 300);
}