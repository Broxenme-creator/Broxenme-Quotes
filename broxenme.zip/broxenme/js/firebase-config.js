// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyDC7MtlDi8Sl7ai3GjEnh06AoR7hZV_4Vs",
    authDomain: "broxenme-quotes.firebaseapp.com",
    projectId: "broxenme-quotes",
    storageBucket: "broxenme-quotes.firebasestorage.app",
    messagingSenderId: "625885740482",
    appId: "1:625885740482:web:fce8637986109f8ab82a5b"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

// Enable offline persistence
db.enablePersistence().catch((err) => {
    console.log('Offline persistence error:', err.code);
});

// ImgBB API key for image uploads
const IMGBB_KEY = '78883b1360bb85b347b444b05aa56826';

// Global state
let currentUser = null;
let allPosts = [];
let unsubscribers = [];
let viewedProfileUid = null;
let currentGroupId = null;
let currentFeedCommentId = null;
let currentDMUser = null;
let audio = null;

console.log('🔥 Firebase initialized');