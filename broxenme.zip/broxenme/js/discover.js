function loadDiscoverPage() {
    const container = document.getElementById('pageContainer');
    container.innerHTML = `
        <div style="max-width:700px;margin:0 auto;padding:1rem">
            <h2 style="margin-bottom:1rem"><i class="fa-solid fa-compass"></i> Discover People</h2>
            <input type="text" id="discoverSearch" placeholder="Search by name, bio, location, or tags..." oninput="searchDiscover()" style="width:100%;padding:1rem;border-radius:25px;border:1px solid var(--accent);background:var(--card);color:var(--text);outline:none;margin-bottom:1rem">
            <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1rem" id="categoryChips">
                <button class="btn btn-small" onclick="filterDiscover('all')">All</button>
                ${quoteTags.map(t => `<button class="btn btn-small" onclick="filterDiscover('${t}')">${t}</button>`).join('')}
            </div>
            <div id="discoverList"></div>
        </div>
    `;
    loadAccounts();
}

function loadAccounts() {
    db.collection('users').onSnapshot(snap => {
        window.allAccounts = [];
        snap.forEach(doc => { const d = doc.data(); d.uid = doc.id; window.allAccounts.push(d); });
    });
}

let discoverFilter = 'all';
function filterDiscover(f) { discoverFilter = f; searchDiscover(); }

function searchDiscover() {
    const q = document.getElementById('discoverSearch')?.value?.toLowerCase() || '';
    let results = (window.allAccounts || []).filter(a =>
        (a.name || '').toLowerCase().includes(q) ||
        (a.bio || '').toLowerCase().includes(q) ||
        (a.location || '').toLowerCase().includes(q) ||
        (a.tags || []).some(t => t.toLowerCase().includes(q))
    );
    if (discoverFilter !== 'all') results = results.filter(a => (a.tags || []).includes(discoverFilter));
    const list = document.getElementById('discoverList');
    if (!list) return;
    list.innerHTML = results.length ? results.map(a => `
        <div class="glass" style="padding:1rem;margin:0.5rem 0;display:flex;align-items:center;gap:1rem;cursor:pointer" onclick="viewProfile('${a.uid}')">
            <img src="${a.photoURL || 'https://placehold.co/50'}" style="width:50px;height:50px;border-radius:50%;object-fit:cover">
            <div style="flex:1"><b>${san(a.name)}</b><p style="color:var(--muted);font-size:0.8rem">${san(a.bio || '')}</p></div>
            <button class="btn btn-small" onclick="event.stopPropagation();viewProfile('${a.uid}');toggleFollowUser('${a.uid}')"><i class="fa-solid fa-user-plus"></i> Follow</button>
        </div>
    `).join('') : '<p style="text-align:center;padding:2rem;color:var(--muted)">No users found</p>';
}