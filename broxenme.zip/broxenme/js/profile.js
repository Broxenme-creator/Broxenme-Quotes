function loadProfilePage(uid) {
    viewedProfileUid = uid || currentUser?.uid;
    const container = document.getElementById('pageContainer');
    container.innerHTML = `
        <div class="profile-wrapper glass">
            <div class="profile-header" id="profileHeaderBg">
                <div class="profile-pic-wrap">
                    <img src="https://placehold.co/140" class="profile-pic" id="profilePic">
                    <input type="file" id="profileUpload" accept="image/*" style="display:none" onchange="uploadProfilePic(event)">
                    <div class="camera-btn" id="profilePicBtn" onclick="document.getElementById('profileUpload').click()"><i class="fa-solid fa-camera"></i></div>
                </div>
            </div>
            <div class="profile-info">
                <h2 id="profileName">Guest</h2>
                <p style="color:var(--muted)"><i class="fa-solid fa-location-dot" style="color:red"></i> <span id="profileLocation">Harare, ZW</span></p>
                <p id="profileBio" style="color:var(--muted);margin:1rem 0"></p>
                <div id="streakBadge" style="margin:0.5rem 0"></div>
                <div class="tag-dropdown" style="margin:0.5rem 0">
                    <button class="btn btn-small"><i class="fa-solid fa-tags"></i> My Tags <i class="fa-solid fa-caret-down"></i></button>
                    <div class="dropdown-menu" id="userTagSelector">${quoteTags.map(t => `<label><input type="checkbox" value="${t}" onchange="updateUserTags()"> ${t}</label>`).join('')}</div>
                </div>
                <div class="profile-stats">
                    <div class="stat"><h3 id="postCount">0</h3><p>Posts</p></div>
                    <div class="stat"><h3 id="followerCount">0</h3><p>Followers</p></div>
                    <div class="stat"><h3 id="followingCount">0</h3><p>Following</p></div>
                    <div class="stat"><h3 id="totalLikes">0</h3><p>Likes</p></div>
                </div>
                <div id="profileActions" style="margin:1rem 0;display:flex;gap:0.5rem;justify-content:center;flex-wrap:wrap"></div>
                <div class="profile-tabs">
                    <button class="profile-tab-btn active" onclick="switchProfileTab('posts')">Posts</button>
                    <button class="profile-tab-btn" onclick="switchProfileTab('saved')">Saved</button>
                    <button class="profile-tab-btn" onclick="switchProfileTab('feeds')">Feeds</button>
                    <button class="profile-tab-btn" onclick="switchProfileTab('groups')">Groups</button>
                </div>
                <div id="profileGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:2rem"></div>
                <div id="savedGrid" style="display:none;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:2rem"></div>
                <div id="feedsGrid" style="display:none;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:2rem"></div>
                <div id="groupsContent" style="display:none"></div>
            </div>
        </div>
    `;
    loadUserProfile(viewedProfileUid);
    loadProfilePosts();
}

function loadUserProfile(uid) {
    if (!uid) return;
    db.collection('users').doc(uid).get().then(doc => {
        if (!doc.exists) return;
        const d = doc.data();
        const isOwn = (uid === currentUser?.uid);
        document.getElementById('profileName').innerHTML = san(d.name);
        document.getElementById('profileBio').innerText = d.bio || '';
        document.getElementById('profileLocation').innerText = d.location || '';
        document.getElementById('followerCount').innerText = d.followers || 0;
        document.getElementById('followingCount').innerText = d.following || 0;
        document.getElementById('streakBadge').innerHTML = `<i class="fa-solid fa-fire"></i> ${d.streak || 0} Day Streak`;
        if (d.photoURL) document.getElementById('profilePic').src = d.photoURL;
        document.getElementById('profilePicBtn').style.display = isOwn ? 'flex' : 'none';
        document.getElementById('profileActions').innerHTML = isOwn
            ? `<button class="btn btn-small" onclick="openEditProfile()"><i class="fa-solid fa-pen"></i> Edit</button>
               <button class="btn btn-small" onclick="shareProfile()"><i class="fa-solid fa-share-nodes"></i> Share</button>
               <button class="btn btn-small" onclick="openCreator('profile')"><i class="fa-solid fa-plus-circle"></i> Post</button>`
            : `<button class="btn btn-small" onclick="toggleFollowUser('${uid}')"><i class="fa-solid fa-user-plus"></i> Follow</button>`;
        document.getElementById('profileHeaderBg').style.backgroundImage = `url(${getRandomWallpaper()})`;
    });
}

function loadProfilePosts() {
    if (!currentUser) return;
    cleanUp();
    const unsub = db.collection('posts').where('authorId', '==', viewedProfileUid || currentUser.uid).orderBy('time', 'desc').onSnapshot(snap => {
        const grid = document.getElementById('profileGrid');
        if (!grid) return;
        let pc = 0, tl = 0;
        grid.innerHTML = '';
        snap.forEach(doc => {
            const p = doc.data();
            grid.innerHTML += `<div style="background:${p.bg};aspect-ratio:1;border-radius:16px;display:flex;align-items:center;justify-content:center;padding:1rem;text-align:center;font-weight:bold;color:white;cursor:pointer;font-size:0.8rem">${san(p.text.substring(0,40))}</div>`;
            pc++; tl += (p.likes || 0);
        });
        document.getElementById('postCount').innerText = pc;
        document.getElementById('totalLikes').innerText = tl;
    });
    unsubscribers.push(unsub);
}

function switchProfileTab(tab) {
    document.querySelectorAll('.profile-tab-btn').forEach(b => { b.classList.remove('active'); b.style.color = 'var(--muted)'; });
    event.target.classList.add('active'); event.target.style.color = 'var(--accent)';
    document.getElementById('profileGrid').style.display = tab === 'posts' ? 'grid' : 'none';
    document.getElementById('savedGrid').style.display = tab === 'saved' ? 'grid' : 'none';
    document.getElementById('feedsGrid').style.display = tab === 'feeds' ? 'grid' : 'none';
    document.getElementById('groupsContent').style.display = tab === 'groups' ? 'block' : 'none';
    if (tab === 'saved') loadSavedPosts();
    if (tab === 'feeds') loadUserFeeds();
    if (tab === 'groups') loadProfileGroups();
}

function loadSavedPosts() {
    if (!currentUser) return;
    db.collection('users').doc(currentUser.uid).get().then(doc => {
        const saved = doc.data()?.savedPosts || [];
        const grid = document.getElementById('savedGrid');
        grid.style.display = 'grid';
        grid.innerHTML = saved.length ? '' : '<p style="text-align:center;padding:2rem;color:var(--muted);grid-column:1/-1">No saved posts</p>';
        saved.forEach(id => {
            db.collection('posts').doc(id).get().then(pd => {
                if (pd.exists) {
                    const p = pd.data();
                    grid.innerHTML += `<div style="background:${p.bg};aspect-ratio:1;border-radius:16px;display:flex;align-items:center;justify-content:center;padding:1rem;text-align:center;font-weight:bold;color:white;font-size:0.75rem">${san(p.text.substring(0,25))}</div>`;
                }
            });
        });
    });
}

function loadUserFeeds() {
    if (!currentUser) return;
    db.collection('feedPosts').where('authorId', '==', currentUser.uid).orderBy('time', 'desc').onSnapshot(snap => {
        const grid = document.getElementById('feedsGrid');
        grid.style.display = 'grid';
        grid.innerHTML = snap.empty ? '<p style="text-align:center;padding:2rem;color:var(--muted);grid-column:1/-1">No feed posts</p>' : '';
        snap.forEach(doc => {
            const p = doc.data();
            grid.innerHTML += `<div style="background:linear-gradient(135deg,#333,#111);aspect-ratio:1;border-radius:16px;display:flex;align-items:center;justify-content:center;padding:1rem;text-align:center;font-weight:bold;color:white;font-size:0.7rem">${san((p.text||'').substring(0,30))}</div>`;
        });
    });
}

function loadProfileGroups() {
    if (!currentUser) return;
    const content = document.getElementById('groupsContent');
    content.style.display = 'block';
    content.innerHTML = '<div id="profileGroupsList"></div>';
    db.collection('groups').where('members', 'array-contains', currentUser.uid).onSnapshot(snap => {
        const list = document.getElementById('profileGroupsList');
        if (!list) return;
        list.innerHTML = snap.empty ? '<p style="text-align:center;padding:2rem;color:var(--muted)">No groups</p>' : '';
        snap.forEach(doc => {
            const g = doc.data();
            list.innerHTML += `<div class="group-card" onclick="openGroupChat('${doc.id}','${san(g.name)}')">
                <div class="group-avatar">${(g.name||'G')[0].toUpperCase()}</div>
                <div class="group-info"><h4>${san(g.name)}</h4><p>${g.memberCount||0} members</p></div>
                <span class="joined-tag"><i class="fa-solid fa-check"></i> Joined</span>
            </div>`;
        });
    });
}

function viewProfile(uid) {
    viewedProfileUid = uid;
    loadProfilePage(uid);
}

async function toggleFollowUser(uid) {
    if (!currentUser || uid === currentUser.uid) return;
    const ref = db.collection('follows').doc(currentUser.uid + '_' + uid);
    const doc = await ref.get();
    if (doc.exists) {
        await ref.delete();
        await db.collection('users').doc(uid).update({ followers: firebase.firestore.FieldValue.increment(-1) });
    } else {
        await ref.set({ follower: currentUser.uid, following: uid });
        await db.collection('users').doc(uid).update({ followers: firebase.firestore.FieldValue.increment(1) });
    }
    loadUserProfile(uid);
}

async function uploadProfilePic(event) {
    const file = event.target.files[0];
    if (!file || !currentUser) return;
    const url = await uploadImage(file);
    if (url) {
        document.getElementById('profilePic').src = url;
        await db.collection('users').doc(currentUser.uid).update({ photoURL: url });
        toast('Photo updated!', 'success');
    }
}

async function updateUserTags() {
    if (!currentUser) return;
    const tags = [];
    document.querySelectorAll('#userTagSelector input:checked').forEach(cb => tags.push(cb.value));
    await db.collection('users').doc(currentUser.uid).update({ tags });
    toast('Tags updated!', 'success');
}

function openEditProfile() {
    document.getElementById('editName').value = document.getElementById('profileName').innerText;
    document.getElementById('editLocation').value = document.getElementById('profileLocation').innerText;
    document.getElementById('editBio').value = document.getElementById('profileBio').innerText || '';
    document.getElementById('editProfileModal').classList.add('active');
}

function closeEditProfile() { document.getElementById('editProfileModal').classList.remove('active'); }

async function saveProfile() {
    const name = document.getElementById('editName').value.trim();
    if (!name) return toast('Name required', 'error');
    await db.collection('users').doc(currentUser.uid).update({
        name, location: document.getElementById('editLocation').value.trim(),
        bio: document.getElementById('editBio').value.trim()
    });
    loadUserProfile(currentUser.uid);
    closeEditProfile();
    toast('Profile updated!', 'success');
}

function shareProfile() {
    navigator.clipboard.writeText(window.location.href);
    toast('Link copied!', 'success');
}