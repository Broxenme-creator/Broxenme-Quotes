function openCreator(source) {
    if (!currentUser) return toast('Login first', 'error');
    document.getElementById('advancedCreator').classList.add('active');
    document.getElementById('creatorText').innerText = 'Your Quote';
    document.getElementById('creatorText').style.cssText = 'top:50%;left:50%;transform:translate(-50%,-50%);font-size:24px;color:#fff;font-family:Poppins;';
    document.getElementById('creatorImage').style.display = 'none';
    document.getElementById('canvasWrapper').style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
    document.getElementById('canvasWrapper').style.aspectRatio = '9/16';
    document.getElementById('creatorPostType').value = source === 'feed' ? 'feed' : 'reel';
    document.getElementById('textSizeSlider').value = 24;
}

function closeCreator() { document.getElementById('advancedCreator').classList.remove('active'); }

function makeDraggable(el) {
    let isDown = false, startX, startY, origLeft, origTop;
    el.onmousedown = function(e) {
        isDown = true; startX = e.clientX; startY = e.clientY;
        origLeft = parseFloat(el.style.left) || 50; origTop = parseFloat(el.style.top) || 50;
        el.style.cursor = 'grabbing'; e.preventDefault();
    };
    document.onmousemove = function(e) {
        if (!isDown) return;
        const wrapper = document.getElementById('canvasWrapper');
        el.style.left = Math.max(0, Math.min(90, origLeft + ((e.clientX - startX) / wrapper.offsetWidth) * 100)) + '%';
        el.style.top = Math.max(0, Math.min(90, origTop + ((e.clientY - startY) / wrapper.offsetHeight) * 100)) + '%';
        el.style.transform = 'none';
    };
    document.onmouseup = function() { isDown = false; el.style.cursor = 'move'; };
    // Touch support
    el.ontouchstart = function(e) {
        isDown = true; startX = e.touches[0].clientX; startY = e.touches[0].clientY;
        origLeft = parseFloat(el.style.left) || 50; origTop = parseFloat(el.style.top) || 50;
    };
    document.ontouchmove = function(e) {
        if (!isDown) return;
        const wrapper = document.getElementById('canvasWrapper');
        el.style.left = Math.max(0, Math.min(90, origLeft + ((e.touches[0].clientX - startX) / wrapper.offsetWidth) * 100)) + '%';
        el.style.top = Math.max(0, Math.min(90, origTop + ((e.touches[0].clientY - startY) / wrapper.offsetHeight) * 100)) + '%';
        el.style.transform = 'none';
    };
    document.ontouchend = function() { isDown = false; };
}

function setCreatorTextColor(color) { document.getElementById('creatorText').style.color = color; }
function setCreatorBgColor(color) { document.getElementById('canvasWrapper').style.background = `linear-gradient(135deg, ${color}, ${color}dd)`; document.getElementById('creatorImage').style.display = 'none'; }
function setCreatorFont(font) { document.getElementById('creatorText').style.fontFamily = font; }
function updateTextSize() { document.getElementById('creatorText').style.fontSize = document.getElementById('textSizeSlider').value + 'px'; }
function cropImage(ratio) { const w = document.getElementById('canvasWrapper'); w.style.aspectRatio = ratio === '1:1' ? '1/1' : ratio === '4:5' ? '4/5' : ratio === '9:16' ? '9/16' : '16/9'; }
function resetCrop() { document.getElementById('canvasWrapper').style.aspectRatio = '9/16'; }

async function uploadCreatorBg(event) {
    const file = event.target.files[0];
    if (!file) return;
    const url = await uploadImage(file);
    if (url) { document.getElementById('creatorImage').src = url; document.getElementById('creatorImage').style.display = 'block'; document.getElementById('canvasWrapper').style.background = ''; }
}

async function submitAdvancedPost() {
    const text = document.getElementById('creatorQuoteInput').value.trim();
    if (!text) return toast('Write a quote!', 'error');
    const type = document.getElementById('creatorPostType').value;
    const bg = document.getElementById('creatorImage').style.display !== 'none'
        ? `url(${document.getElementById('creatorImage').src})`
        : document.getElementById('canvasWrapper').style.background;
    
    if (type === 'reel') {
        await db.collection('posts').add({
            text, bg, font: document.getElementById('creatorText').style.fontFamily,
            tags: [], authorId: currentUser.uid, authorName: currentUser.email.split('@')[0],
            authorPic: currentUser.photoURL || 'https://placehold.co/40',
            time: firebase.firestore.FieldValue.serverTimestamp(), likes: 0, views: 0, shares: 0, commentsCount: 0
        });
    } else {
        await db.collection('feedPosts').add({
            text, imageUrl: document.getElementById('creatorImage').style.display !== 'none' ? document.getElementById('creatorImage').src : '',
            authorId: currentUser.uid, authorName: currentUser.email.split('@')[0],
            authorPic: currentUser.photoURL || 'https://placehold.co/40',
            time: firebase.firestore.FieldValue.serverTimestamp(), likes: 0, views: 0, shares: 0, commentsCount: 0
        });
    }
    closeCreator();
    toast('Posted!', 'success');
}