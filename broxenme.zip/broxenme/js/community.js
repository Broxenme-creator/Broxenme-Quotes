function loadCommunityPage() {
    const container = document.getElementById('pageContainer');
    container.innerHTML = `
        <div class="community-container">
            <div class="community-tabs">
                <div class="comm-tab active" onclick="switchCommTab('feed')"><i class="fa-solid fa-newspaper"></i> Feed</div>
                <div class="comm-tab" onclick="switchCommTab('groups')"><i class="fa-solid fa-comments"></i> Groups</div>
            </div>
            <div id="feedTab">
                <button class="btn btn-outline" onclick="openCreator('feed')" style="margin-bottom:0.5rem"><i class="fa-solid fa-plus"></i> Create Post</button>
                <button class="btn btn-outline" onclick="createPoll()" style="margin-bottom:1rem"><i class="fa-solid fa-chart-bar"></i> Create Poll</button>
                <div id="communityFeed"></div>
            </div>
            <div id="groupsTab" style="display:none">
                <div style="display:flex;gap:0.5rem;margin-bottom:1rem">
                    <input type="text" id="groupSearchInput" placeholder="🔍 Search groups..." oninput="searchGroups()" style="flex:1;padding:0.8rem;border-radius:25px;border:1px solid var(--accent);background:var(--card);color:var(--text);outline:none">
                    <button class="btn" onclick="openNewGroup()" style="width:auto"><i class="fa-solid fa-plus"></i> New</button>
                </div>
                <div id="groupsList"></div>
            </div>
        </div>
    `;
    if (currentUser) { loadFeed(); loadGroups(); }
}

function switchCommTab(tab) {
    document.querySelectorAll('.comm-tab').forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('feedTab').style.display = tab === 'feed' ? 'block' : 'none';
    document.getElementById('groupsTab').style.display = tab === 'groups' ? 'block' : 'none';
}

// FEED
function loadFeed() {
    db.collection('feedPosts').orderBy('time', 'desc').limit(20).onSnapshot(snap => {
        const feed = document.getElementById('communityFeed');
        if (!feed) return;
        if (snap.empty) { feed.innerHTML = '<p style="text-align:center;padding:2rem;color:var(--muted)">No posts yet</p>'; return; }
        feed.innerHTML = '';
        snap.forEach(doc => {
            const p = doc.data(); p.id = doc.id;
            feed.innerHTML += `
            <div class="feed-card">
                <div class="feed-header">
                    <img src="${p.authorPic || 'https://placehold.co/40'}" onclick="viewProfile('${p.authorId}')">
                    <div><b onclick="viewProfile('${p.authorId}')" style="cursor:pointer">${san(p.authorName)}</b><br><small style="color:var(--muted)">${p.time?.toDate?.()?.toLocaleString() || 'Just now'}</small></div>
                </div>
                <div><p>${san(p.text || '')}</p>${p.imageUrl ? `<img src="${p.imageUrl}" style="width:100%;border-radius:10px;margin:0.5rem 0">` : ''}${p.pollOptions ? renderPollHTML(p.id, p.pollOptions, p.pollVotes || {}) : ''}</div>
                <div>${reactionEmojis.map(e => `<button class="reaction-emoji" onclick="addFeedReaction('${doc.id}','${e}')">${e}</button>`).join('')}</div>
                <div class="feed-stats">
                    <span onclick="likeFeed('${doc.id}')"><i class="fa-regular fa-heart"></i> ${p.likes || 0}</span>
                    <span onclick="openFeedComments('${doc.id}')"><i class="fa-solid fa-comment"></i> ${p.commentsCount || 0}</span>
                </div>
            </div>`;
        });
    });
}

async function likeFeed(id) {
    if (!currentUser) return toast('Login first', 'error');
    const ref = db.collection('feedLikes').doc(currentUser.uid + '_' + id);
    const doc = await ref.get();
    if (doc.exists) { await ref.delete(); await db.collection('feedPosts').doc(id).update({ likes: firebase.firestore.FieldValue.increment(-1) }); }
    else { await ref.set({}); await db.collection('feedPosts').doc(id).update({ likes: firebase.firestore.FieldValue.increment(1) }); }
}

async function createPoll() {
    const q = prompt('Poll question:');
    if (!q) return;
    const opts = prompt('Options (comma separated):');
    if (!opts) return;
    const options = opts.split(',').map(o => o.trim()).filter(o => o);
    if (options.length < 2) return toast('Need at least 2 options', 'error');
    await db.collection('feedPosts').add({
        text: q, pollOptions: options, pollVotes: {},
        authorId: currentUser.uid, authorName: currentUser.email.split('@')[0],
        authorPic: currentUser.photoURL || 'https://placehold.co/40',
        time: firebase.firestore.FieldValue.serverTimestamp(), likes: 0, views: 0, shares: 0, commentsCount: 0
    });
    toast('Poll created!', 'success');
}

function renderPollHTML(postId, options, votes) {
    let total = 0;
    Object.values(votes).forEach(v => total += v);
    return `<div style="background:var(--card);padding:1rem;border-radius:10px;margin:0.5rem 0">
        <h4><i class="fa-solid fa-chart-bar"></i> Poll</h4>
        ${options.map((opt, i) => {
            const v = votes[i] || 0;
            const pct = total > 0 ? Math.round((v / total) * 100) : 0;
            return `<div class="poll-option" onclick="votePoll('${postId}',${i})" style="padding:0.5rem;margin:0.3rem 0;background:rgba(255,255,255,0.05);border-radius:8px;cursor:pointer">
                <span>${opt}</span>
                <div style="flex:1;height:6px;background:rgba(255,255,255,0.1);border-radius:3px;margin:0 0.5rem"><div style="height:100%;background:var(--accent);border-radius:3px;width:${pct}%"></div></div>
                <span style="font-size:0.7rem">${pct}%</span>
            </div>`;
        }).join('')}
    </div>`;
}

async function votePoll(postId, optionIndex) {
    if (!currentUser) return;
    const ref = db.collection('feedPosts').doc(postId);
    const doc = await ref.get();
    const votes = doc.data().pollVotes || {};
    if (votes[currentUser.uid] !== undefined) return toast('Already voted!', 'info');
    votes[currentUser.uid] = optionIndex;
    await ref.update({ pollVotes: votes });
}

// FEED COMMENTS
function openFeedComments(feedId) {
    currentFeedCommentId = feedId;
    const modal = document.getElementById('feedCommentsModal');
    if (modal) modal.classList.add('active');
    loadFeedComments(feedId);
}

function closeFeedComments() {
    document.getElementById('feedCommentsModal')?.classList.remove('active');
    currentFeedCommentId = null;
}

function loadFeedComments(feedId) {
    db.collection('feedPosts').doc(feedId).collection('comments').orderBy('time', 'asc').onSnapshot(snap => {
        const list = document.getElementById('feedCommentsList');
        if (!list) return;
        if (snap.empty) { list.innerHTML = '<p style="text-align:center;color:var(--muted);padding:1rem">No comments</p>'; return; }
        db.collection('feedPosts').doc(feedId).get().then(pd => {
            const authorId = pd.data()?.authorId;
            list.innerHTML = '';
            snap.forEach(doc => {
                const c = doc.data();
                list.innerHTML += `<div class="comment-item">
                    <span class="comment-author">${san(c.authorName)}</span>${c.authorId === authorId ? '<span class="creator-badge">Creator</span>' : ''}
                    <div class="comment-text">${san(c.text)}</div>
                    <div class="comment-actions">
                        <span onclick="likeFeedComment('${feedId}','${doc.id}')"><i class="fa-regular fa-heart"></i> ${c.likes || 0}</span>
                        <span onclick="dislikeFeedComment('${feedId}','${doc.id}')"><i class="fa-regular fa-thumbs-down"></i> ${c.dislikes || 0}</span>
                    </div>
                </div>`;
            });
        });
    });
}

async function submitFeedComment() {
    if (!currentFeedCommentId || !currentUser) return;
    const input = document.getElementById('feedCommentInput');
    const text = input?.value?.trim();
    if (!text) return;
    await db.collection('feedPosts').doc(currentFeedCommentId).collection('comments').add({
        text, authorId: currentUser.uid, authorName: currentUser.email.split('@')[0],
        time: firebase.firestore.FieldValue.serverTimestamp(), likes: 0, dislikes: 0
    });
    await db.collection('feedPosts').doc(currentFeedCommentId).update({ commentsCount: firebase.firestore.FieldValue.increment(1) });
    if (input) input.value = '';
}

async function likeFeedComment(feedId, commentId) {
    if (!currentUser) return;
    const ref = db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).collection('likes').doc(currentUser.uid);
    const doc = await ref.get();
    if (doc.exists) { await ref.delete(); await db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).update({ likes: firebase.firestore.FieldValue.increment(-1) }); }
    else { await ref.set({}); await db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).update({ likes: firebase.firestore.FieldValue.increment(1) }); }
}

async function dislikeFeedComment(feedId, commentId) {
    if (!currentUser) return;
    const ref = db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).collection('dislikes').doc(currentUser.uid);
    const doc = await ref.get();
    if (doc.exists) { await ref.delete(); await db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).update({ dislikes: firebase.firestore.FieldValue.increment(-1) }); }
    else { await ref.set({}); await db.collection('feedPosts').doc(feedId).collection('comments').doc(commentId).update({ dislikes: firebase.firestore.FieldValue.increment(1) }); }
}

// GROUPS
function openNewGroup() {
    const name = prompt('Group name:');
    if (!name) return;
    const desc = prompt('Description (optional):') || '';
    const goal = prompt('Goal (optional):') || '';
    db.collection('groups').add({
        name, description: desc, goal, createdBy: currentUser.uid,
        members: [currentUser.uid], memberCount: 1, admins: [currentUser.uid],
        lastMsg: '', lastTime: firebase.firestore.FieldValue.serverTimestamp()
    }).then(() => toast('Group created!', 'success'));
}

function loadGroups() {
    db.collection('groups').onSnapshot(snap => {
        window.allGroups = [];
        snap.forEach(doc => { const g = doc.data(); g.id = doc.id; window.allGroups.push(g); });
        renderGroupsList(window.allGroups, document.getElementById('groupsList'));
    });
}

function renderGroupsList(groups, container) {
    if (!container) return;
    if (!groups.length) { container.innerHTML = '<p style="text-align:center;padding:2rem;color:var(--muted)">No groups</p>'; return; }
    container.innerHTML = groups.map(g => {
        const isMember = g.members?.includes(currentUser?.uid);
        return `<div class="group-card" ${isMember ? `onclick="openGroupChat('${g.id}','${san(g.name)}')"` : ''}>
            <div class="group-avatar">${(g.name || 'G')[0].toUpperCase()}</div>
            <div class="group-info"><h4>${san(g.name)}</h4><p>${g.memberCount || 0} members</p></div>
            ${isMember ? `<span class="joined-tag"><i class="fa-solid fa-check"></i> Joined</span><span class="unread-badge" id="unread_${g.id}">0</span>` : `<button class="btn btn-small" onclick="event.stopPropagation();joinGroup('${g.id}')"><i class="fa-solid fa-plus"></i> Join</button>`}
        </div>`;
    }).join('');
}

async function joinGroup(id) {
    if (!currentUser) return;
    const ref = db.collection('groups').doc(id);
    const doc = await ref.get();
    let members = doc.data().members || [];
    if (members.includes(currentUser.uid)) return;
    members.push(currentUser.uid);
    await ref.update({ members, memberCount: members.length });
    toast('Joined!', 'success');
}

function searchGroups() {
    const q = document.getElementById('groupSearchInput')?.value?.toLowerCase() || '';
    const filtered = (window.allGroups || []).filter(g => (g.name || '').toLowerCase().includes(q));
    renderGroupsList(filtered, document.getElementById('groupsList'));
}

// GROUP CHAT
function openGroupChat(id, name) {
    currentGroupId = id;
    document.getElementById('groupChatWindow')?.classList.add('active');
    document.getElementById('groupChatName').innerText = name;
    db.collection('groups').doc(id).get().then(doc => {
        document.getElementById('groupChatMemberCount').innerText = (doc.data().memberCount || 0) + ' members';
        document.getElementById('groupChatAvatar').src = 'https://placehold.co/45/ADFF2F/000?text=' + (name || 'G')[0].toUpperCase();
    });
    if (currentUser) db.collection('groups').doc(id).collection('readReceipts').doc(currentUser.uid).set({ lastRead: firebase.firestore.FieldValue.serverTimestamp() }, { merge: true });
    const unsub = db.collection('groups').doc(id).collection('messages').orderBy('time', 'asc').onSnapshot(snap => {
        const mc = document.getElementById('groupChatMessages');
        if (!mc) return;
        mc.innerHTML = '';
        snap.forEach(doc => {
            const m = doc.data();
            mc.innerHTML += `<div class="msg ${m.from === currentUser?.uid ? 'me' : 'other'}">${san(m.text)}</div>`;
        });
        mc.scrollTop = mc.scrollHeight;
    });
    unsubscribers.push(unsub);
}

function closeGroupChat() {
    document.getElementById('groupChatWindow')?.classList.remove('active');
    currentGroupId = null;
}

function sendGroupMsg() {
    const input = document.getElementById('groupChatInput');
    const text = input?.value?.trim();
    if (!text || !currentGroupId) return;
    db.collection('groups').doc(currentGroupId).collection('messages').add({
        text, from: currentUser.uid, senderName: currentUser.email.split('@')[0],
        time: firebase.firestore.FieldValue.serverTimestamp()
    }).then(() => {
        db.collection('groups').doc(currentGroupId).update({ lastMsg: text, lastTime: firebase.firestore.FieldValue.serverTimestamp() });
        if (input) input.value = '';
    });
}